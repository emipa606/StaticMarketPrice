﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using UnityEngine;
using Verse;
using RimWorld;
using Harmony;

namespace StaticMarketPrice.HarmonyPatches
{
    [HarmonyPatch(typeof(Tradeable), "GetPriceFor")]
    public static class StaticMarketPrice_GetPriceFor
    {
        public static bool Prefix(ref float __result, ref Tradeable __instance, TradeAction action)
        {
            __result = __instance.BaseMarketValue *
                TradeSession.trader.TraderKind.PriceTypeFor(__instance.ThingDef, action).PriceMultiplier();
            return false;
        }
    }

    [HarmonyPatch(typeof(Tradeable), "GetPriceTooltip")]
    public static class StaticMarketPrice_GetPriceTooltip
    {
        public static bool Prefix(ref string __result, ref Tradeable __instance, TradeAction action)
        {
            __result = StatDefOf.MarketValue.LabelCap + ": " + __instance.BaseMarketValue;
            return false;
        }
    }
}
