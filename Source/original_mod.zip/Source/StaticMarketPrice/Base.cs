﻿using RimWorld;
using Verse;

namespace StaticMarketPrice
{
    [StaticConstructorOnStartup]
    public static class Initialization
    {
        static Initialization()
        {
            HarmonyPatches.HPatcher.Init();
        }
    }
}
